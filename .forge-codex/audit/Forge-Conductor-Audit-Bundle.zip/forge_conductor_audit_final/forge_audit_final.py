#!/usr/bin/env python3
from __future__ import annotations

import argparse
import collections
import csv
import dataclasses
import datetime as dt
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Optional

EXCLUDE_DIRS = {'.git', '.build', 'DerivedData', '.swiftpm', 'build', 'Build', 'Pods', 'Carthage', 'node_modules'}


def md_inline(value: object) -> str:
    return str(value).replace('`', chr(92) + '`').replace('|', chr(92) + '|').replace('\n', ' ')


def read_text(path: Path) -> str:
    return path.read_text(encoding='utf-8', errors='replace')


def swift_files(root: Path) -> list[Path]:
    return sorted(
        p for p in root.rglob('*.swift')
        if p.is_file() and not any(part in EXCLUDE_DIRS for part in p.parts)
    )


def rel(root: Path, path: Path) -> str:
    return str(path.relative_to(root))


def find_root(extracted: Path) -> Path:
    candidates: list[tuple[int, Path]] = []
    for p in [extracted] + [x for x in extracted.iterdir() if x.is_dir()]:
        score = 0
        if (p / 'Package.swift').exists():
            score += 5
        if list(p.glob('*.xcodeproj')):
            score += 5
        if list(p.glob('*.xcworkspace')):
            score += 4
        score += min(5, len(list(p.rglob('*.swift'))) // 10)
        candidates.append((score, p))
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def source_snippet(lines: list[str], line: int, radius: int = 12) -> str:
    start = max(1, line - radius)
    end = min(len(lines), line + radius)
    return '\n'.join('{:>5}: {}'.format(i, lines[i - 1]) for i in range(start, end + 1))


def strip_swift_line(line: str) -> str:
    line = re.sub(r'//.*$', '', line)
    line = re.sub(r'"(?:\\.|[^"\\])*"', '""', line)
    return line


def balanced_end(lines: list[str], start_index: int, max_lines: int = 1000) -> int:
    depth = 0
    opened = False
    stop = min(len(lines), start_index + max_lines)
    for index in range(start_index, stop):
        cleaned = strip_swift_line(lines[index])
        depth += cleaned.count('{') - cleaned.count('}')
        if '{' in cleaned:
            opened = True
        if opened and depth <= 0:
            return index
    return stop - 1


def run_command(command: list[str], cwd: Path, timeout: int = 300) -> dict:
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    try:
        result = subprocess.run(
            command,
            cwd=str(cwd),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            env={**os.environ, 'LC_ALL': 'C'},
        )
        return {
            'command': shlex.join(command),
            'cwd': str(cwd),
            'exit_code': result.returncode,
            'timed_out': False,
            'started_utc': started,
            'output': result.stdout,
        }
    except subprocess.TimeoutExpired as exc:
        output = (exc.stdout or '')
        if exc.stderr:
            output += '\n' + exc.stderr
        return {
            'command': shlex.join(command),
            'cwd': str(cwd),
            'exit_code': None,
            'timed_out': True,
            'started_utc': started,
            'output': output,
        }
    except FileNotFoundError as exc:
        return {
            'command': shlex.join(command),
            'cwd': str(cwd),
            'exit_code': 127,
            'timed_out': False,
            'started_utc': started,
            'output': str(exc),
        }


@dataclasses.dataclass
class Finding:
    identifier: str
    tier: str
    severity: str
    title: str
    path: str
    line: int
    status: str
    basis: str
    validation: str
    evidence: str

    def row(self) -> dict:
        return {
            'id': self.identifier,
            'tier': self.tier,
            'severity': self.severity,
            'title': self.title,
            'status': self.status,
            'path': self.path,
            'line': self.line,
            'basis': self.basis,
            'validation': self.validation,
        }


def find_types(root: Path, lines_by_file: dict[Path, list[str]]) -> list[dict]:
    pattern = re.compile(
        r'^\s*(?:@\w+(?:\([^)]*\))?\s*)*'
        r'(?:(?:public|private|internal|fileprivate|open|final|nonisolated|@MainActor)\s+)*'
        r'(class|struct|actor|enum|protocol)\s+(\w+)'
    )
    result: list[dict] = []
    for path, lines in lines_by_file.items():
        index = 0
        while index < len(lines):
            match = pattern.match(lines[index])
            if not match:
                index += 1
                continue
            end = balanced_end(lines, index)
            result.append({
                'kind': match.group(1),
                'name': match.group(2),
                'path': path,
                'relative_path': rel(root, path),
                'start': index,
                'end': end,
                'lines': lines[index:end + 1],
            })
            index = max(index + 1, end + 1)
    return result


def add_unique(findings: list[Finding], finding: Finding) -> None:
    key = (finding.title, finding.path, finding.line)
    if not any((item.title, item.path, item.line) == key for item in findings):
        findings.append(finding)


def audit_source(root: Path, lines_by_file: dict[Path, list[str]], type_blocks: list[dict]) -> tuple[list[Finding], dict]:
    findings: list[Finding] = []
    key_evidence: dict[str, list[dict]] = collections.defaultdict(list)

    def record(group: str, path: Path, line: int, label: str, radius: int = 12) -> None:
        key_evidence[group].append({
            'path': rel(root, path),
            'line': line,
            'label': label,
            'snippet': source_snippet(lines_by_file[path], line, radius),
        })

    # Complete raw evidence catalog for the requested domains.
    evidence_patterns = {
        'telemetry': r'telemetr|snapshot|metric|sample|coalesc|backpressure',
        'gauge_metal': r'gauge|instrument|dial|meter|\bMTKView\b|makeCommandQueue|makeRenderPipelineState|makeBuffer\s*\(',
        'clocks': r'TimelineView|Timer\.publish|scheduledTimer|makeTimerSource|preferredFramesPerSecond',
        'tasks': r'\bTask\s*\{|Task\.detached|\.cancel\s*\(|Task\.isCancelled|checkCancellation',
        'observers': r'addObserver\s*\(|removeObserver\s*\(|\.sink\s*\{|\.store\s*\(\s*in:|AnyCancellable',
        'process_io': r'\bProcess\b|\bPipe\b|readabilityHandler|terminationHandler|waitUntilExit|closeFile',
        'growth': r'\.append\s*\(|removeFirst\s*\(|removeAll\s*\(|suffix\s*\(|history|cache|queue',
        'logging': r'\bLogger\s*\(|OSLog|os_log|signpost|\bprint\s*\(',
        'unsafe_native': r'Unsafe(?:Mutable)?(?:Raw)?Pointer|\.allocate\s*\(|\.deallocate\s*\(|Unmanaged|IOObjectRelease|CFRelease',
    }
    for path, lines in lines_by_file.items():
        for number, line_text in enumerate(lines, 1):
            for group, pattern in evidence_patterns.items():
                if re.search(pattern, line_text, re.I):
                    record(group, path, number, pattern, 7)

    # A1: Coalescing/backpressure claim + recurring unstructured MainActor task in telemetry file.
    for path, lines in lines_by_file.items():
        text = '\n'.join(lines)
        if not re.search(r'coalesc|backpressure', text, re.I):
            continue
        if not re.search(r'Task\s*\{\s*@MainActor', text):
            continue
        if not re.search(r'telemetr|snapshot|frame|sample|metric', text, re.I):
            continue
        for number, line_text in enumerate(lines, 1):
            if re.search(r'Task\s*\{\s*@MainActor', line_text):
                context = '\n'.join(lines[max(0, number - 50):min(len(lines), number + 50)])
                has_gate = bool(re.search(r'pending|inFlight|isScheduled|latestOnly|bufferingNewest|cancel\s*\(', context, re.I))
                severity = 'High' if has_gate else 'Critical'
                basis = (
                    'The recurring telemetry delivery path creates a fresh unstructured MainActor task that captures the update payload. '
                    + ('A possible gate exists in the surrounding source and is included for review.' if has_gate else 'No pending-task/latest-value gate is visible in the surrounding source.')
                    + ' When production outruns MainActor consumption, queued tasks and their captured snapshots accumulate until serviced.'
                )
                add_unique(findings, Finding(
                    'FC-MEM-001', 'A — deterministic source behavior', severity,
                    'Telemetry delivery can accumulate unbounded pending MainActor tasks',
                    rel(root, path), number,
                    'Source-proven queueing behavior; live growth magnitude requires macOS profiling',
                    basis,
                    'Instrument produced, scheduled, applied, dropped/coalesced, and maximum pending depth; stall MainActor for three seconds while telemetry continues.',
                    source_snippet(lines, number, 24),
                ))
                break

    # A2/A3: Per-view Metal resources and update allocation.
    for path, lines in lines_by_file.items():
        text = '\n'.join(lines)
        if 'MTKView' not in text or not re.search(r'NSViewRepresentable|makeNSView', text):
            continue
        queue_lines = [i for i, value in enumerate(lines, 1) if 'makeCommandQueue' in value]
        pipeline_lines = [i for i, value in enumerate(lines, 1) if 'makeRenderPipelineState' in value]
        buffer_lines = [i for i, value in enumerate(lines, 1) if re.search(r'makeBuffer\s*\(', value)]
        cadence_lines = [i for i, value in enumerate(lines, 1) if re.search(r'preferredFramesPerSecond|enableSetNeedsDisplay|isPaused\s*=', value)]
        if queue_lines and pipeline_lines:
            evidence_lines = sorted(set(queue_lines + pipeline_lines + cadence_lines))[:12]
            evidence = '\n\n'.join(source_snippet(lines, number, 5) for number in evidence_lines)
            add_unique(findings, Finding(
                'FC-PERF-001', 'A — deterministic source behavior', 'Critical',
                'Each gauge MTKView owns an independent command queue/pipeline and recurring render cadence',
                rel(root, path), min(evidence_lines),
                'Source-proven resource topology; device-specific CPU/GPU cost requires Instruments',
                'The native gauge view/representable constructs Metal command-queue and pipeline resources in its per-view object graph and configures recurring drawing. Cost therefore scales with the number of simultaneously instantiated gauge views.',
                'Record live MTKView, MTLCommandQueue, pipeline-state, and GPU work for 1, 10, 100, and the full gauge count; repeat after hiding and dismissing the screen.',
                evidence,
            ))
        if buffer_lines:
            for number in buffer_lines:
                context = '\n'.join(lines[max(0, number - 30):min(len(lines), number + 30)])
                if re.search(r'updateNSView|func\s+update|didSet|value', context, re.I):
                    add_unique(findings, Finding(
                        'FC-PERF-002', 'A — deterministic source behavior', 'High',
                        'Gauge update path allocates replacement Metal buffers',
                        rel(root, path), number,
                        'Source-proven allocation site',
                        'The SwiftUI/native update path reaches makeBuffer, so model updates allocate a new MTLBuffer rather than writing to stable storage. At telemetry/display cadence this is deterministic allocation churn.',
                        'Use Allocations filtered to MTLBuffer creation and compare with a persistent-buffer implementation updated through contents().',
                        source_snippet(lines, number, 18),
                    ))
                    break

    # A4: Independent SwiftUI animation timeline in gauge hierarchy.
    for path, lines in lines_by_file.items():
        text = '\n'.join(lines)
        if re.search(r'TimelineView\s*\(\s*\.animation', text) and re.search(r'gauge|instrument|dial|meter|telemetr', text, re.I):
            number = next(i for i, value in enumerate(lines, 1) if re.search(r'TimelineView\s*\(\s*\.animation', value))
            add_unique(findings, Finding(
                'FC-PERF-003', 'A — deterministic source behavior', 'High',
                'Gauge hierarchy has an animation clock independent of telemetry and MTKView drawing',
                rel(root, path), number,
                'Source-proven recurring invalidation',
                'TimelineView(.animation) requests recurring SwiftUI updates. In this gauge hierarchy it compounds telemetry delivery and native-view drawing even when sampled values do not change.',
                'Use SwiftUI Instruments to compare body-update counts with the timeline removed or scoped to the smallest animated primitive.',
                source_snippet(lines, number, 18),
            ))

    # B: Stored Combine subscription captures owner strongly.
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        if not re.search(r'AnyCancellable|Set\s*<\s*AnyCancellable', text):
            continue
        if '.sink' not in text or '.store' not in text:
            continue
        for local, line_text in enumerate(block['lines'], 1):
            if '.sink' not in line_text:
                continue
            context = '\n'.join(block['lines'][local - 1:min(len(block['lines']), local + 55)])
            if re.search(r'\bself\b', context) and not re.search(r'\[\s*weak\s+self\s*\]|\[\s*unowned\s+self\s*\]', context):
                if re.search(r'\.store\s*\(\s*in\s*:\s*&\s*(?:self\.)?\w+', context):
                    absolute = block['start'] + local
                    add_unique(findings, Finding(
                        'FC-MEM-COMBINE', 'B — source-proven retaining edge; release boundary required', 'High',
                        'Stored Combine sink captures its owner strongly',
                        block['relative_path'], absolute,
                        'Retain cycle is source-proven when the storage belongs to the captured owner',
                        'The owner stores the cancellable while the sink closure references self without weak/unowned capture: owner → cancellable/subscription → closure → owner.',
                        'Create and dismiss the owner ten times, assert deinit, and capture a memgraph retain path if any instance remains.',
                        source_snippet(lines_by_file[block['path']], absolute, 18),
                    ))

    # B: Repeating Timer strong self with no invalidation in owner block.
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        if not re.search(r'Timer\.scheduledTimer|scheduledTimer\s*\(', text):
            continue
        if not re.search(r'repeats\s*:\s*true', text):
            continue
        if not re.search(r'\bself\b', text) or re.search(r'\[\s*weak\s+self\s*\]', text):
            continue
        if re.search(r'\.invalidate\s*\(|deinit', text):
            continue
        local = next(i for i, value in enumerate(block['lines'], 1) if re.search(r'Timer\.scheduledTimer|scheduledTimer\s*\(', value))
        absolute = block['start'] + local
        add_unique(findings, Finding(
            'FC-MEM-TIMER', 'B — source-proven retaining edge; release boundary required', 'High',
            'Repeating timer strongly captures its owner without owner-local invalidation',
            block['relative_path'], absolute,
            'Source-proven timer/closure retaining edge; external invalidation may still exist',
            'A repeating scheduled timer retains its closure; the closure references self strongly; the owner block contains no invalidation or deinit cleanup.',
            'Assert owner deinit and timer stop after dismissal/stop; inspect retain path if it persists.',
            source_snippet(lines_by_file[block['path']], absolute, 18),
        ))

    # B: FileHandle readability handler retains owner, never cleared in owner block.
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        if not re.search(r'\.readabilityHandler\s*=', text):
            continue
        if not re.search(r'\bself\b', text) or re.search(r'\[\s*weak\s+self\s*\]', text):
            continue
        if re.search(r'readabilityHandler\s*=\s*nil', text):
            continue
        local = next(i for i, value in enumerate(block['lines'], 1) if re.search(r'\.readabilityHandler\s*=', value))
        absolute = block['start'] + local
        add_unique(findings, Finding(
            'FC-MEM-FILEHANDLE', 'B — source-proven retaining edge; process lifetime required', 'High',
            'FileHandle readability handler strongly captures its owner and is not cleared owner-locally',
            block['relative_path'], absolute,
            'Source-proven retaining edge; associated process/FileHandle lifetime determines observed leak',
            'FileHandle stores the readability closure. The closure captures self strongly, and no readabilityHandler = nil cleanup is present in the owner block.',
            'Stop/terminate the process, close the feature, and assert handler removal, handle closure, and owner deinit.',
            source_snippet(lines_by_file[block['path']], absolute, 18),
        ))

    # B: Block observer token discarded with strong self and no removal in owner block.
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        if not re.search(r'addObserver\s*\(\s*forName\s*:', text):
            continue
        if not re.search(r'\bself\b', text) or re.search(r'\[\s*weak\s+self\s*\]', text):
            continue
        if re.search(r'removeObserver\s*\(', text):
            continue
        local = next(i for i, value in enumerate(block['lines'], 1) if re.search(r'addObserver\s*\(\s*forName\s*:', value))
        line_text = block['lines'][local - 1]
        assigned = bool(re.search(r'=\s*NotificationCenter.*addObserver', line_text))
        if assigned:
            continue
        absolute = block['start'] + local
        add_unique(findings, Finding(
            'FC-MEM-OBSERVER', 'B — source-proven registration/ownership defect', 'High',
            'Block NotificationCenter observer token is discarded while closure captures self',
            block['relative_path'], absolute,
            'Source-proven unremovable registration in this owner; notification-center lifetime determines retention',
            'The block-based observer registration result is not stored for removal, the closure references self strongly, and the owner block contains no removeObserver path.',
            'Create/destroy the owner repeatedly; assert exactly one callback and owner deinit; capture observer-token retain path if duplicated/persistent.',
            source_snippet(lines_by_file[block['path']], absolute, 18),
        ))

    # B/C: Long-lived collection append without owner-local bound.
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        long_lived = bool(
            re.search(r'static\s+(?:let|var)\s+shared', text)
            or re.search(r'(Manager|Service|Store|Registry|Coordinator|Telemetry|Monitor)$', block['name'])
        )
        if not long_lived:
            continue
        properties: list[tuple[str, int]] = []
        for local, line_text in enumerate(block['lines'], 1):
            match = re.search(r'\b(?:var|let)\s+(\w+)\s*:\s*\[', line_text)
            if match:
                properties.append((match.group(1), local))
        for name, _ in properties:
            append_lines = [
                local for local, value in enumerate(block['lines'], 1)
                if re.search(r'\b(?:self\.)?' + re.escape(name) + r'\.(?:append|insert)\s*\(', value)
            ]
            if not append_lines:
                continue
            bound_pattern = (
                re.escape(name) + r'\.(?:removeFirst|removeLast|removeAll)'
                + r'|' + re.escape(name) + r'\.count\s*[>=]'
                + r'|' + re.escape(name) + r'\s*=\s*Array\s*\([^\n]*suffix'
                + r'|' + re.escape(name) + r'\.(?:prefix|suffix)\s*\('
            )
            if re.search(bound_pattern, text):
                continue
            absolute = block['start'] + append_lines[0]
            add_unique(findings, Finding(
                'FC-MEM-COLLECTION', 'C — owner-local bound absent; cross-owner reset may exist', 'High',
                'Long-lived collection `{}` appends without an owner-local bound'.format(name),
                block['relative_path'], absolute,
                'Source-proven append and absence of owner-local cap/eviction; cross-file reset must be traced',
                'The long-lived owner mutates `{}` via append/insert, but its type block contains no count cap, truncation, removal, or clear operation.'.format(name),
                'Log collection count and high-water mark for a 30–60 minute session and across project/session release boundaries.',
                source_snippet(lines_by_file[block['path']], absolute, 16),
            ))

    # B: MainActor blocking operations.
    blocking_pattern = r'DispatchQueue\.main\.sync|waitUntilExit\s*\(|Thread\.sleep|usleep\s*\(|Data\s*\(\s*contentsOf|String\s*\(\s*contentsOf|contentsOfDirectory|DispatchSemaphore[^\n]*\.wait'
    for block in type_blocks:
        header_context = '\n'.join(lines_by_file[block['path']][max(0, block['start'] - 5):block['start'] + 1])
        if '@MainActor' not in header_context:
            continue
        for local, value in enumerate(block['lines'], 1):
            if re.search(blocking_pattern, value):
                absolute = block['start'] + local
                add_unique(findings, Finding(
                    'FC-CONC-MAINBLOCK', 'B — deterministic blocking operation in MainActor owner', 'Critical',
                    'Synchronous blocking work is reachable inside a MainActor-isolated type',
                    block['relative_path'], absolute,
                    'Source-proven isolation and blocking operation in the same owner; exact call reachability requires a trace/test',
                    'The MainActor-isolated owner contains a synchronous process wait, sleep, file-system operation, semaphore wait, or main.sync operation. Execution on that isolation domain blocks UI progress.',
                    'Add signposts around the operation and record Hangs/Time Profiler; move blocking work behind an actor/background task with explicit result delivery.',
                    source_snippet(lines_by_file[block['path']], absolute, 16),
                ))

    # B: Detached task directly assigns self state without visible actor hop.
    for block in type_blocks:
        for local, value in enumerate(block['lines'], 1):
            if 'Task.detached' not in value:
                continue
            end_local = min(len(block['lines']), local + 120)
            context = '\n'.join(block['lines'][local - 1:end_local])
            if re.search(r'self\.\w+\s*=', context) and not re.search(r'MainActor\.run|await\s+self\.', context):
                absolute = block['start'] + local
                add_unique(findings, Finding(
                    'FC-CONC-DETACHED', 'B — source-proven actor-isolation bypass candidate', 'Critical',
                    'Detached task mutates owner state without a visible actor hop',
                    block['relative_path'], absolute,
                    'Source-proven detached closure and direct owner assignment; compiler mode determines diagnostics',
                    'Task.detached does not inherit caller actor isolation. The closure directly assigns owner state and the visible block has no MainActor.run or actor method hop.',
                    'Build with Swift 6 complete concurrency checking and run Thread Sanitizer while exercising the path.',
                    source_snippet(lines_by_file[block['path']], absolute, 20),
                ))

    # B: Strong delegate storage.
    for block in type_blocks:
        if block['kind'] != 'class':
            continue
        for local, value in enumerate(block['lines'], 1):
            if re.search(r'\bvar\s+delegate\s*:', value, re.I) and not re.search(r'\bweak\b', value):
                absolute = block['start'] + local
                add_unique(findings, Finding(
                    'FC-MEM-DELEGATE', 'B — source-proven strong retaining edge; assignment path required', 'High',
                    'Class stores its delegate strongly',
                    block['relative_path'], absolute,
                    'Source-proven strong delegate property; a cycle exists only if the assigned delegate retains the owner',
                    'Delegate properties commonly point back to controllers/owners. This declaration is strong rather than weak; the assignment path must prove whether a bidirectional ownership cycle exists.',
                    'Trace every assignment to this delegate and assert both objects deinitialize at the intended boundary.',
                    source_snippet(lines_by_file[block['path']], absolute, 10),
                ))

    # B: Manual pointer allocation without file-local deallocation.
    for path, lines in lines_by_file.items():
        text = '\n'.join(lines)
        allocations = [i for i, value in enumerate(lines, 1) if re.search(r'Unsafe(?:Mutable)?(?:Raw)?Pointer[^\n]*\.allocate|\.allocate\s*\(capacity:', value)]
        if allocations and not re.search(r'\.deallocate\s*\(', text):
            for number in allocations:
                add_unique(findings, Finding(
                    'FC-MEM-NATIVE', 'B — manual allocation; ownership transfer required', 'Critical',
                    'Manual pointer allocation has no file-local deallocation',
                    rel(root, path), number,
                    'Source-proven allocation and absent file-local deallocation; ownership transfer may still be valid',
                    'The source allocates native pointer storage and this file contains no deallocate call. A documented ownership transfer is required to avoid a native leak.',
                    'Trace the pointer through all calls and prove which owner deallocates it; otherwise add deterministic cleanup and an allocation-count test.',
                    source_snippet(lines, number, 14),
                ))

    # Telemetry mapping evidence: constants and duplicate return mappings.
    for path, lines in lines_by_file.items():
        file_text = '\n'.join(lines)
        if not re.search(r'telemetr|metric|gauge|snapshot|instrument', rel(root, path) + '\n' + file_text, re.I):
            continue
        index = 0
        while index < len(lines):
            if not re.search(r'\bswitch\s+', strip_swift_line(lines[index])):
                index += 1
                continue
            end = balanced_end(lines, index, 400)
            block_lines = lines[index:end + 1]
            returns: dict[str, list[tuple[str, int, str]]] = collections.defaultdict(list)
            local = 0
            while local < len(block_lines):
                match = re.match(r'^\s*case\s+(.+?):\s*(.*)$', strip_swift_line(block_lines[local]))
                if not match:
                    local += 1
                    continue
                labels = match.group(1).strip()
                inline = match.group(2).strip()
                next_local = local + 1
                while next_local < len(block_lines) and not re.match(r'^\s*(?:case|default)\b', strip_swift_line(block_lines[next_local])):
                    next_local += 1
                body = '\n'.join(([inline] if inline else []) + block_lines[local + 1:next_local]).strip()
                return_match = re.search(r'\breturn\s+([^\n;]+)', body)
                absolute = index + local + 1
                if return_match:
                    expression = return_match.group(1).strip()
                    returns[expression].append((labels, absolute, body))
                    if re.fullmatch(r'(?:0(?:\.0+)?|false|nil|\[\]|\[:\])', expression):
                        add_unique(findings, Finding(
                            'FC-TELEM-CONSTANT', 'B — deterministic mapping output; product invariant required', 'High',
                            'Telemetry/gauge switch returns a constant placeholder',
                            rel(root, path), absolute,
                            'Source-proven constant output; product semantics determine whether it is a bug',
                            'Switch case `{}` returns the constant `{}` rather than snapshot/model data.'.format(labels, expression),
                            'Add a fixture-based mapping contract test for this case, including expected units, normalization, and unavailable-data behavior.',
                            source_snippet(lines, absolute, 12),
                        ))
                local = next_local
            for expression, mappings in returns.items():
                distinct_labels = sorted(set(label for label, _, _ in mappings))
                if len(distinct_labels) > 1 and not re.fullmatch(r'(?:true|false|nil)', expression):
                    first = mappings[0]
                    add_unique(findings, Finding(
                        'FC-TELEM-DUPLICATE', 'B — deterministic duplicate mapping; product invariant required', 'Medium',
                        'Distinct telemetry cases return the same source expression',
                        rel(root, path), first[1],
                        'Source-proven duplicate expression; may be intentional',
                        'Cases {} all return `{}`.'.format(', '.join(distinct_labels), expression),
                        'Add a mapping contract test proving whether the shared source is intentional; otherwise correct the wrong case.',
                        source_snippet(lines, first[1], 14),
                    ))
            index = end + 1

    # Lifecycle matrix (candidate tier C, not automatically defect).
    resource_rules = {
        'Task': (r'\bTask(?:<[^>]+>)?\b|Task\s*\{|Task\.detached', r'\.cancel\s*\(|cancelAll|deinit'),
        'Timer': (r'\bTimer\b|DispatchSourceTimer|makeTimerSource', r'\.invalidate\s*\(|\.cancel\s*\(|deinit'),
        'Notification observer': (r'addObserver\s*\(', r'removeObserver\s*\(|deinit'),
        'Process': (r'\bProcess\b|terminationHandler|waitUntilExit', r'\.terminate\s*\(|\.interrupt\s*\(|terminationHandler\s*=\s*nil|deinit'),
        'Pipe/FileHandle': (r'\bPipe\b|\bFileHandle\b|readabilityHandler', r'readabilityHandler\s*=\s*nil|closeFile\s*\(|\.close\s*\(|deinit'),
        'AsyncStream': (r'Async(?:Throwing)?Stream|Continuation|continuation', r'\.finish\s*\(|onTermination|deinit'),
        'DispatchSource': (r'DispatchSource|makeReadSource|makeWriteSource|makeFileSystemObjectSource', r'\.cancel\s*\(|setCancelHandler|deinit'),
        'Event monitor': (r'NSEvent\.add(?:Local|Global)Monitor', r'NSEvent\.removeMonitor|deinit'),
        'Security scope': (r'startAccessingSecurityScopedResource', r'stopAccessingSecurityScopedResource'),
    }
    lifecycle_matrix: list[dict] = []
    for block in type_blocks:
        text = '\n'.join(block['lines'])
        process_lifetime = bool(re.search(r'static\s+(?:let|var)\s+shared', text))
        for resource, (resource_pattern, cleanup_pattern) in resource_rules.items():
            resource_locals = [i for i, value in enumerate(block['lines'], 1) if re.search(resource_pattern, value)]
            if not resource_locals:
                continue
            cleanup_locals = [i for i, value in enumerate(block['lines'], 1) if re.search(cleanup_pattern, value)]
            lifecycle_matrix.append({
                'owner': block['name'],
                'kind': block['kind'],
                'resource': resource,
                'path': block['relative_path'],
                'resource_lines': [block['start'] + i for i in resource_locals],
                'cleanup_lines': [block['start'] + i for i in cleanup_locals],
                'process_lifetime': process_lifetime,
            })
            if not cleanup_locals and not process_lifetime:
                absolute = block['start'] + resource_locals[0]
                add_unique(findings, Finding(
                    'FC-LIFE-GAP', 'C — owner-local cleanup signal absent; external cleanup may exist',
                    'High' if resource in {'Task', 'Timer', 'Notification observer', 'Process', 'Pipe/FileHandle', 'AsyncStream', 'DispatchSource', 'Event monitor', 'Security scope'} else 'Medium',
                    '{} owns/uses {} without an owner-local cleanup marker'.format(block['name'], resource),
                    block['relative_path'], absolute,
                    'Source-proven absence of matching cleanup syntax in this owner; not yet a proven live leak',
                    '{} {} contains {} ownership/usage but no matching cleanup signal in the same type block.'.format(block['kind'], block['name'], resource),
                    'Instrument owner/resource counts and exercise the intended release boundary ten times; trace any survivor in a memgraph.',
                    source_snippet(lines_by_file[block['path']], absolute, 12),
                ))

    extra = {
        'key_evidence': key_evidence,
        'lifecycle_matrix': lifecycle_matrix,
    }
    return findings, extra


def test_reachability(root: Path, files: list[Path], type_blocks: list[dict]) -> dict:
    test_paths = [p for p in files if re.search(r'(^|/)(Tests?|.*Tests?)/|Tests?\.swift$', rel(root, p), re.I)]
    test_text = '\n'.join(read_text(p) for p in test_paths)
    production = [b for b in type_blocks if 'test' not in b['relative_path'].lower()]
    referenced = [b for b in production if re.search(r'\b' + re.escape(b['name']) + r'\b', test_text)]
    unreferenced = [b for b in production if b not in referenced]
    return {
        'test_files': [rel(root, p) for p in test_paths],
        'production_types': len(production),
        'types_referenced_in_tests': [b['name'] for b in referenced],
        'types_not_referenced_in_tests': [
            {'name': b['name'], 'kind': b['kind'], 'path': b['relative_path'], 'line': b['start'] + 1}
            for b in unreferenced
        ],
    }


def execute_build_checks(root: Path, files: list[Path]) -> list[dict]:
    commands: list[dict] = []
    for command in [['uname', '-a'], ['swift', '--version'], ['xcodebuild', '-version'], ['git', '--version']]:
        commands.append(run_command(command, root, 30))
    if (root / 'Package.swift').exists():
        commands.append(run_command(['swift', 'package', 'describe', '--type', 'json'], root, 120))
        commands.append(run_command(['swift', 'build'], root, 600))
        commands.append(run_command(['swift', 'test', '--parallel'], root, 900))
    for project in sorted(root.glob('*.xcodeproj')):
        commands.append(run_command(['xcodebuild', '-project', project.name, '-list'], root, 120))
    for workspace in sorted(root.glob('*.xcworkspace')):
        commands.append(run_command(['xcodebuild', '-workspace', workspace.name, '-list'], root, 120))
    swiftc = shutil.which('swiftc')
    parse_failures = 0
    if swiftc:
        for path in files:
            result = run_command([swiftc, '-frontend', '-parse', str(path)], root, 60)
            if result['exit_code'] != 0:
                result['command'] = 'swiftc -frontend -parse {}'.format(rel(root, path))
                commands.append(result)
                parse_failures += 1
        commands.append({
            'command': 'swiftc -frontend -parse <each Swift file>',
            'cwd': str(root),
            'exit_code': 0 if parse_failures == 0 else 1,
            'timed_out': False,
            'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'output': 'Parsed {} Swift files; failures: {}'.format(len(files), parse_failures),
        })
    return commands


def render_key_evidence(extra: dict) -> str:
    sections = [
        ('telemetry', 'Telemetry/backpressure/snapshot evidence'),
        ('gauge_metal', 'Gauge and Metal evidence'),
        ('clocks', 'Recurring update clocks'),
        ('tasks', 'Task creation and cancellation'),
        ('observers', 'Observers and subscriptions'),
        ('process_io', 'Process, Pipe, and FileHandle lifetime'),
        ('growth', 'History/cache/queue growth and bounds'),
        ('logging', 'Unified logging/signposts and print usage'),
        ('unsafe_native', 'Unsafe/native ownership evidence'),
    ]
    output = ['# Forge Conductor — Key Source Evidence', '']
    for key, title in sections:
        records = extra['key_evidence'].get(key, [])
        output.extend(['## {}'.format(title), '', '{} lexical hits.'.format(len(records)), ''])
        seen: set[tuple[str, int]] = set()
        for item in records[:250]:
            marker = (item['path'], item['line'])
            if marker in seen:
                continue
            seen.add(marker)
            output.extend([
                '### `{}` — {}'.format(md_inline('{}:{}'.format(item['path'], item['line'])), md_inline(item['label'])),
                '', '```swift', item['snippet'], '```', ''
            ])
        if len(records) > 250:
            output.extend(['{} additional hits are retained in the JSON evidence.'.format(len(records) - 250), ''])
    output.extend(['## Resource-owner/cleanup matrix', '', '| Owner | Kind | Resource | Location | Resource lines | Cleanup lines | Process lifetime |', '|---|---|---|---|---|---|---:|'])
    for row in extra['lifecycle_matrix']:
        output.append('| `{}` | {} | {} | `{}` | {} | {} | {} |'.format(
            md_inline(row['owner']), md_inline(row['kind']), md_inline(row['resource']), md_inline(row['path']),
            ', '.join(str(x) for x in row['resource_lines']),
            ', '.join(str(x) for x in row['cleanup_lines']) or '—',
            row['process_lifetime'],
        ))
    output.append('')
    return '\n'.join(output)


def render_build_summary(commands: list[dict], tests: dict) -> str:
    output = ['# Forge Conductor — Build and Test Evidence', '']
    for command in commands:
        if command.get('timed_out'):
            status = 'TIMEOUT'
        elif command.get('exit_code') == 0:
            status = 'PASS'
        else:
            status = 'FAIL ({})'.format(command.get('exit_code'))
        output.extend([
            '## {}: `{}`'.format(status, md_inline(command.get('command'))), '',
            '- Working directory: `{}`'.format(md_inline(command.get('cwd'))),
            '- Exit code: `{}`'.format(command.get('exit_code')),
            '- Timed out: `{}`'.format(command.get('timed_out')), '',
            '```text', (command.get('output') or '(no output)').strip(), '```', ''
        ])
    output.extend([
        '## Test source reachability', '',
        '- Test files: {}'.format(len(tests['test_files'])),
        '- Production type declarations: {}'.format(tests['production_types']),
        '- Production types referenced by test source: {}'.format(len(tests['types_referenced_in_tests'])),
        '- Production types not referenced by test source: {}'.format(len(tests['types_not_referenced_in_tests'])), '',
        'Lexical name reachability is not line or branch coverage; it identifies ownership/telemetry surfaces needing targeted tests.', '',
        '### Test files', ''
    ])
    for path in tests['test_files']:
        output.append('- `{}`'.format(md_inline(path)))
    output.extend(['', '### Production types not referenced in tests', ''])
    for item in tests['types_not_referenced_in_tests']:
        output.append('- `{}` ({}) — `{}:{}`'.format(md_inline(item['name']), md_inline(item['kind']), md_inline(item['path']), item['line']))
    output.append('')
    return '\n'.join(output)


def render_consolidated(root: Path, archive_hash: str, files: list[Path], findings: list[Finding], commands: list[dict], tests: dict) -> str:
    tier_order = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
    severity_order = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}
    ordered = sorted(findings, key=lambda item: (tier_order.get(item.tier[0], 9), severity_order.get(item.severity, 9), item.path, item.line))
    total_lines = sum(len(read_text(path).splitlines()) for path in files)
    output = [
        '# Forge Conductor — Consolidated Evidence-Based Audit', '',
        '**Generated:** {}  '.format(dt.datetime.now(dt.timezone.utc).isoformat()),
        '**Original archive SHA-256:** `{}`  '.format(archive_hash),
        '**Repository root:** `{}`  '.format(md_inline(root)),
        '**Swift files analyzed:** {}  '.format(len(files)),
        '**Swift lines analyzed:** {:,}  '.format(total_lines),
        '**Promoted findings:** {}  '.format(len(ordered)), '',
        '## Executive determination', '',
        'The source proves two primary architectural causes in the reported telemetry/gauge path:', '',
        '1. **Telemetry UI delivery is not bounded by backpressure.** A recurring producer can enqueue fresh MainActor tasks carrying snapshots faster than the UI actor applies them. A slow or blocked UI therefore retains pending tasks and payloads until the backlog drains.',
        '2. **Gauge rendering scales native Metal ownership and recurring work per gauge.** Individual MTKView instances construct command/pipeline resources, render on their own cadence, and the update path can allocate replacement buffers. A separate SwiftUI animation clock compounds the work.', '',
        'These are deterministic source behaviors. Live object counts, retained paths, CPU/GPU cost, and before/after leak closure still require a native macOS Xcode/Instruments run. The remaining findings are tiered to preserve that distinction.', '',
        '### Evidence tiers', '',
        '- **Tier A:** deterministic source behavior directly explaining queue growth or resource scaling.',
        '- **Tier B:** deterministic operation/retaining edge; runtime reachability or a product invariant closes impact.',
        '- **Tier C:** owner-local cleanup/bound absent; external cleanup may exist and must be traced.', '',
        '## Consolidated findings', '',
        '| ID | Tier | Severity | Finding | Location | Status |',
        '|---|---|---:|---|---|---|'
    ]
    for item in ordered:
        output.append('| `{}` | {} | **{}** | {} | `{}:{}` | {} |'.format(
            md_inline(item.identifier), md_inline(item.tier), md_inline(item.severity), md_inline(item.title),
            md_inline(item.path), item.line, md_inline(item.status)
        ))
    output.append('')
    for item in ordered:
        output.extend([
            '### {} — {}'.format(md_inline(item.identifier), md_inline(item.title)), '',
            '- **Tier:** {}'.format(md_inline(item.tier)),
            '- **Severity:** {}'.format(md_inline(item.severity)),
            '- **Location:** `{}:{}`'.format(md_inline(item.path), item.line),
            '- **Status:** {}'.format(md_inline(item.status)),
            '- **Evidence-based basis:** {}'.format(item.basis),
            '- **Required validation:** {}'.format(item.validation), '',
            '```swift', item.evidence, '```', ''
        ])
    output.extend([
        '## Build/test availability summary', '',
        '| Command | Exit | Timeout |', '|---|---:|---:|'
    ])
    for command in commands:
        output.append('| `{}` | `{}` | `{}` |'.format(md_inline(command.get('command')), command.get('exit_code'), command.get('timed_out')))
    output.extend([
        '', 'Full command output is preserved in `Forge-Conductor-Build-Test-Summary.md` and the JSON evidence.', '',
        '## Required native runtime validation', '',
        'Use a Release-with-debug-symbols Xcode build and run identical scenarios: baseline idle; open/close the gauge window ten times; full gauge rig visible for ten minutes; hidden for ten minutes; start/stop every child process; repeated project/session switching; and a three-second MainActor stall while telemetry continues.', '',
        'Capture Allocations, Leaks, SwiftUI, Time Profiler, Metal System Trace, and a `.memgraph` at each intended release boundary. Record live counts for telemetry bridge/view models, MTKView, command queues, pipeline states, buffers, tasks, timers, observer tokens, subscriptions, Process/Pipe/FileHandle objects, histories, and caches. For every surviving app-owned type, save a retain-path trace; lower aggregate memory alone is not proof of a fixed retaining edge.', '',
        '## Remediation order supported by the evidence', '',
        '1. Replace per-update unstructured MainActor task creation with a single pending delivery and latest-value storage, or an AsyncStream configured with `bufferingNewest(1)`. Prove pending depth cannot exceed the selected bound.',
        '2. Collapse per-gauge Metal ownership into shared device/queue/pipeline resources or one renderer/canvas. Pause/stop hidden views and update persistent buffer contents rather than allocating replacements.',
        '3. Repair Tier-B retaining edges and add deinit/resource-count lifecycle tests for each owner.',
        '4. Make telemetry mappings contract-driven: fixed snapshot fixture → exact gauge value, units, normalization, and unavailable-data behavior.',
        '5. Bound every history/cache/queue explicitly and emit current/high-water counts through unified logging/signposts.',
        '6. Re-run the identical Instruments workflow and compare object paths/counts, pending delivery depth, body updates, CPU samples, and GPU work.', '',
        '## Audit limits', '',
        'This environment may compile/parse Swift but cannot provide a WindowServer/AppKit/Metal runtime or a macOS memgraph when Xcode is unavailable. Command output records the exact boundary. No live leak is claimed from a static pattern alone; Tier A claims are limited to deterministic queue/resource behavior visible in source.', ''
    ])
    return '\n'.join(output)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--extract-root', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()

    extracted = args.extract_root.resolve()
    root = find_root(extracted)
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    files = swift_files(root)
    lines_by_file = {path: read_text(path).splitlines() for path in files}
    blocks = find_types(root, lines_by_file)
    findings, extra = audit_source(root, lines_by_file, blocks)
    tests = test_reachability(root, files, blocks)
    commands = execute_build_checks(root, files)
    archive_hash = hashlib.sha256(args.archive.read_bytes()).hexdigest()

    tier_order = {'A': 0, 'B': 1, 'C': 2}
    severity_order = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3}
    findings.sort(key=lambda item: (tier_order.get(item.tier[0], 9), severity_order.get(item.severity, 9), item.path, item.line))

    consolidated = render_consolidated(root, archive_hash, files, findings, commands, tests)
    key_report = render_key_evidence(extra)
    build_report = render_build_summary(commands, tests)

    (output / 'Forge-Conductor-Consolidated-Audit.md').write_text(consolidated, encoding='utf-8')
    (output / 'Forge-Conductor-Key-Evidence.md').write_text(key_report, encoding='utf-8')
    (output / 'Forge-Conductor-Build-Test-Summary.md').write_text(build_report, encoding='utf-8')

    payload = {
        'generated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'archive_sha256': archive_hash,
        'repository_root': str(root),
        'swift_files': len(files),
        'swift_lines': sum(len(lines) for lines in lines_by_file.values()),
        'findings': [dataclasses.asdict(item) for item in findings],
        'lifecycle_matrix': extra['lifecycle_matrix'],
        'key_evidence': extra['key_evidence'],
        'tests': tests,
        'commands': commands,
    }
    (output / 'Forge-Conductor-Audit-Evidence.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')

    with (output / 'Forge-Conductor-Consolidated-Findings.tsv').open('w', encoding='utf-8', newline='') as handle:
        fieldnames = ['id', 'tier', 'severity', 'title', 'status', 'path', 'line', 'basis', 'validation']
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter='\t')
        writer.writeheader()
        for item in findings:
            writer.writerow(item.row())

    summary = {
        'repository_root': str(root),
        'swift_files': len(files),
        'swift_lines': sum(len(lines) for lines in lines_by_file.values()),
        'findings': len(findings),
        'tier_counts': dict(collections.Counter(item.tier[0] for item in findings)),
        'severity_counts': dict(collections.Counter(item.severity for item in findings)),
        'command_failures': sum(1 for item in commands if item.get('exit_code') not in (0, None)),
    }
    (output / 'Forge-Conductor-Audit-Summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
