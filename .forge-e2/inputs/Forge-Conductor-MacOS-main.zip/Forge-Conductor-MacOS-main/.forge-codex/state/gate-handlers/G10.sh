#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
"$ROOT/.forge-codex/scripts/validate_acceptance.py" G10 --repo "$ROOT" --criteria-output "$ROOT/.forge-codex/state/gate-results/G10.criteria.json"
